package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.ifaces.StudentRepository;
import com.example.demo.services.AnotherStudentService;
import com.example.demo.services.StudentService;

import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.BDDMockito.*;


@SpringBootTest
@AutoConfigureMockMvc
public class TestAnotherStudentService {

	
    
    @MockBean
    StudentRepository repo;

	@Autowired
	AnotherStudentService service;
    
    String  stud1 = "kamala";
    
    @Test
    void getStudents() throws Exception { 
    	    
     BDDMockito.given(repo.findById(1)).willReturn(stud1);

      Assertions.assertEquals("kamala",service.getStudent(1));
      
     
         }

}
