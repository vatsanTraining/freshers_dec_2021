package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.ifaces.StudentRepository;
import com.example.demo.services.StudentService;

@SpringBootTest
public class TestStudentService {

	@Autowired
    StudentService service;
   

	
	@Test
	void testgetStudent() {
		
		String actual = service.getStudent(1);
		String expected ="Kamala";
		
		Assertions.assertEquals(actual,expected);
		
	}
    
    

}
