package com.example.demo.fake;
import java.util.*;
public interface InvoiceRepository {

	public int add(Invoice entity);
	public  Collection<Invoice> findAll();
	
}
