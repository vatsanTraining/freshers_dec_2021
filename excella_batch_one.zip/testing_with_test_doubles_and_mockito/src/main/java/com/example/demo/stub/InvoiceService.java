package com.example.demo.stub;

import java.util.Collection;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
public class InvoiceService {

	private InvoiceRepository invRepo;
	
	
	
	public int addInvoice(Invoice entity) {
		
		return this.invRepo.add(entity);
	}
	
	public Collection<Invoice> findAll() {
		
		return this.invRepo.findAll()
				 .stream().filter(e -> e.getAmount()<5000)
				          .collect(Collectors.toList());
	}
}
