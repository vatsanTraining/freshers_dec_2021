package com.example.demo.dummy;

public interface EmailRepository {

	public String sendMessage(String message);
}
