package com.example.demo.dummy;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TestInvoiceService {

	@DisplayName("Test InvoiceService class addInvoice method return 1 for successful insert")
	@Test
	void testForAddSuccess() {
		
		// Dependencies are created
		InvoiceRepository invRepo = new InvoiceRepoImpl();
		EmailRepository emailRepo = new DummyEmailRepo();
		
		// Dependencies are passed the second argument is a dummy object
		InvoiceService service = new InvoiceService(invRepo, emailRepo);
		
		
		Invoice invoice = new Invoice(1010,"Ramesh", 450);
		
		// calling the method under test
		int actual = service.addInvoice(invoice);
		int expected = 1;
		
		// asserting the behaviour
		assertEquals(actual, expected);
	}
}
