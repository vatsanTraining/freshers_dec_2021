package com.example.demo.dummy;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class DummyEmailRepo implements EmailRepository {

	@Override
	public String sendMessage(String message) {

    
	  throw new AssertionError("Un Implemented");
	}

}
