package com.example.demo.stub;

import java.util.Arrays;
import java.util.Collection;

public class InvoiceRepositoryStub implements InvoiceRepository {

	@Override
	public int add(Invoice entity) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Collection<Invoice> findAll() {
		return Arrays.asList(new Invoice(101,"Ramesh",4949),new Invoice(102,"Suresh",8482));
	}

}
