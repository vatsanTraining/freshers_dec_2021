package com.example.demo.fake;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


public class TestInvoiceServiceWithFake {

	@DisplayName("Test InvoiceService class addInvoice method "
			+ "should return 0 if no element is present with the key else "
			+ " 1 if there is already an element")
	@Test
	void testForAddSuccess() {
		
		// Dependencies are created	int actual = service.addInvoice(invoice);
		
		InvoiceRepository repo = new FakeInvoiceRepoImpl();
		InvoiceService service = new InvoiceService(repo);
		
		Invoice entity = new Invoice(102,"Rajesh", 200);
		
		int expected = 0;
		int actual = service.addInvoice(entity);
				
		// asserting the behaviour
		assertEquals(actual, expected);
		
		
		Invoice entity2 = new Invoice(103,"Rajesh", 200);

		int expected1 = 1;
		int actual1 = service.addInvoice(entity);
				
		// asserting the behaviour
		assertEquals(actual1, expected1,"Testing again");
		
	}
}
