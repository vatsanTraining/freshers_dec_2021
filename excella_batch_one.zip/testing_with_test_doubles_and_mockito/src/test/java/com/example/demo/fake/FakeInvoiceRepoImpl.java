package com.example.demo.fake;

import java.util.Collection;
import java.util.HashMap;


public class FakeInvoiceRepoImpl implements InvoiceRepository {

	private HashMap<Integer, Invoice> invList;
	
	public FakeInvoiceRepoImpl() {
		super();

		 invList= new HashMap<>();
	}

	@Override
	public int add(Invoice entity) {
		
		Invoice added= invList.put(entity.getInvoiceNumber(), entity);
		
		return (added!=null)?1:0;
	}

	@Override
	public Collection<Invoice> findAll() {
		return invList.values();
	}

}
