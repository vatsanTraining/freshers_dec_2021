TESTING SCENARIO

=> DONE  => 1) getBook Method should not return null value for choices 1,2,3
=> DONE  => 2) getBook Method should  return null value for choices 4
=> DONE =>  3) getBook Method must throw RunTimeException when the input value is 
   negative number
=> DONE => 4) getDiscount Method should return 0.10 discount for price less than or equal to 200
=> DONE => 5) getDiscount Method should return 0.15 discount for price greater than 200 and 
       less than or equal to 500
6) getDiscount Method should be completed with 100 ms

