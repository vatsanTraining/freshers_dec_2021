package com.example.demo;

public class Greeting {

	public String getMessage() {
		
		return "Hello";
	}
}
