package com.example.demo;

// The usdToInr method should not return negative value
public class CurrencyConverter {

	
	public double usdToInr(double amt) {
		
		return amt * 100.00;
	}
	
	
}
