package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
	//static Greeting grtObj;
	
	Greeting grtObj;
   @BeforeAll
   public static void init() {
	   
	   System.out.println("Before All Called");
		// grtObj = new Greeting();

   }

   @BeforeEach
   public void startUp() {
	   
	   System.out.println("Before Each Called =====");
	   grtObj=new Greeting();
   }
	@Test
	public void testGreetMethodReturnsNull() {
		
		String actual = grtObj.getMessage();
		assertNull(actual);
		
	}
	
	@Test
	public void testGreetMethodReturnsNotNull() {
		
		String actual = grtObj.getMessage();
		
		assertNotNull(actual);
		
	}
	
	@Test
	@DisplayName(value = "To Test The method return a String with value Hello")
	public void testMethodReturnsString() {
		
		Greeting grtObj = new Greeting();
		String actual = grtObj.getMessage();
		
		assertNotNull(actual);
		
	}
	
}
