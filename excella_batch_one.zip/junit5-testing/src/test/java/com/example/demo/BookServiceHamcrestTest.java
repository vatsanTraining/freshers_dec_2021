package com.example.demo;
import static org.hamcrest.Matchers.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat; 

import com.example.demo.model.Book;
public class BookServiceHamcrestTest {

	
	@DisplayName(value = "Test Book Class has a Property author")
	@Test
	void testBookHasAuthorProp() {
		
		Book book = new Book();
		
		assertThat(book,hasProperty("author"));
	}
	
	
	@DisplayName(value = "getBook Method in Book Service should return a book "
			+ "           with price less than 100 for book with id 101")
	@Test
	void testPriceOfFirstBook() {
		
	}
	
}
