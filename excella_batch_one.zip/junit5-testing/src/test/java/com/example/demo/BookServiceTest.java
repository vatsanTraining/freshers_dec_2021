package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static java.time.Duration.ofMillis;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.platform.engine.support.hierarchical.ThrowableCollector;

import java.time.*;
import com.example.demo.model.Book;
import com.example.demo.services.BookService;

import javafx.util.Duration;


public class BookServiceTest {

	private BookService service;
	@BeforeAll
	public static void init() {
		//System.out.println("Before All Called");
	}
	
	@BeforeEach
	public  void setUp()  {
		//System.out.println("BEFORE EACH  CALLED");
		
		service = new BookService();
		
	}
	
	
	
	@Test
	@DisplayName("getBook Method should not return null value for choices 1 to 3")
	 void testGetBookMethodNotNull() {
		
		//System.out.println(" Dummy Test One  called");
		
//		Book actual = service.getBook(2);
//		assertNotNull(actual);
		
		assertAll("getBook Method with choice 1 to 3",
				
					() -> assertNotNull(service.getBook(1)),
					() -> assertNotNull(service.getBook(2)),
					() -> assertNotNull(service.getBook(3))
					
				);
		
		
	}
	
	@ParameterizedTest
	@ValueSource(ints = {1,2,3})
	void testGetBookMethodWithParam(int key) {
		
		assertNotNull(service.getBook(key));
		
	}
	
	
	@Test
	@DisplayName("getBook Method should return null value for choice 4")
	 void testGetBookMethodReturnNull() {
	
	
		assertNull(service.getBook(4));
	}
	
	@Test
	@DisplayName(value = "Must throw RuntimeException for getBook Method with negative argument")
	void testForException() {
		
		Throwable exception =
				  assertThrows(RuntimeException.class, () -> {
					  service.getBook(-2);
				  });
	}
	
	
	@Test
	@DisplayName(value = "getDiscount Method should return 0.10 discount "
			+ "for price less than or equal to 200")
	void testForTenpercentDiscount() {
		
		Book book = service.getBook(1);
		double actual = service.getDiscount(book);
		double expected = 0.10;
		
		assertEquals(expected,actual);
		
	}
	@DisplayName(value = "getDiscount Method should be completed with 100 ms")
	@Test
	void testGetBookCompletionTiming() {

		Book book = service.getBook(3);
		double actual = service.getDiscount(book);
		double expected = 0.15;
		
      double value =  assertTimeout(ofMillis(100), 
    		        () -> service.getDiscount(book) );

      assertEquals(actual, expected);
	}
	

	@DisplayName(value = "getDiscount Method should return 0.05")
	@Test
	@Disabled("Disabled till timeout bug in the method is fixed")
	void testGetBookTestFivePercentDiscount() {

		Book book = service.getBook(1);
		double actual = service.getDiscount(book);
		double expected = 0.05;
		
      assertEquals(actual, expected);
	}
    @Test
    @DisplayName("GetAllBooks method should return a List with index "
    		+ "position 1,3,5 not being null")
    void testGetAllBooksPostion() {
    	
    	 assertFalse(true,"Not Yet Implemented");
    }
    
	@AfterAll
	public static void destory() {
		//System.out.println("After All Called");
	}
	
	@AfterEach
	public  void tearDown() {
		//System.out.println("AFTER EACH  CALLED");
	}
	
}
